#include <QCoreApplication>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlDriver>
#include <QDebug>
//"SELECT * FROM DeviceCurtain"
void DealOLDTABLE(QString cmd)
{
    QString deviceID, deviceName,positionID,manufacture,unitType,
            ipAddress,moduleInfo,secondType,describe;
    int deviceType,status,disable;
    QString parm[12];
    QSqlQuery query;
    if (query.exec(cmd))
    {
        //        int numRows = 0;  //询问数据库驱动，是否驱动含有某种特性
        //        if (db.driver()->hasFeature(QSqlDriver::QuerySize))
        //        {
        //            numRows = query.size();  //如果支持结果影响的行数，那么直接记录下来
        //        }
        //        else
        //        {
        //            query.last(); //否则定位到结果***，qt 文档说，这个方法非常慢
        //            numRows = query.at() + 1;
        //            query.seek(-1);
        //        }
        while(query.next())
        {  //定位结果到下一条记录
            if(cmd.contains("DeviceAircond"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                parm[1]    = query.value(11).toString();
                parm[2]    = query.value(12).toString();
                disable    = query.value(13).toInt();
                describe   = "windSpeed#I,mode#I,temperature#R";
            }
            else if(cmd.contains("DeviceAirQuality"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                parm[2]    = query.value(11).toString();
                parm[3]    = query.value(12).toString();
                parm[4]    = query.value(13).toString();
                disable    = query.value(14).toInt();
                describe   = "formaldehyde#D,tvoc#D,pm25#D,temperature#D,humidity#D";
            }
            else if(cmd.contains("DeviceAudio"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                parm[1]    = query.value(11).toString();
                parm[2]    = query.value(12).toString();
                parm[3]    = query.value(13).toString();
                disable    = query.value(14).toInt();
                describe   = "volume#I,soundChannel#I,songInfo#I,playMode#I";
            }
            else if(cmd.contains("DeviceButton"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                disable    = query.value(10).toInt();
            }
            else if(cmd.contains("DeviceComplexSensor"))
            {
                deviceID   = query.value(0).toString();
                deviceType = query.value(1).toInt();
                positionID = query.value(2).toString();
                deviceName = query.value(3).toString();
                manufacture= query.value(4).toString();
                secondType = query.value(5).toString();
                unitType   = query.value(6).toString();
                ipAddress  = query.value(7).toString();
                moduleInfo = query.value(8).toString();
                status     = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "detail#T";
            }
            else if(cmd.contains("DeviceCurtain"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "opening#I";
            }
            else if(cmd.contains("DeviceDecoder"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                parm[2]    = query.value(11).toString();
                parm[3]    = query.value(12).toString();
                disable    = query.value(13).toInt();
                describe   = "state#I,musicVolume#I,micVolume#I,effectVolume#I";
            }
            else if(cmd.contains("DeviceDivAdjust"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "state#I,percent#I";
            }
            else if(cmd.contains("DeviceFreshAir"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                parm[2]    = query.value(11).toString();
                disable    = query.value(12).toInt();
                describe   = "state#I,freshAirMode#I,freshAirSpeed#I";
            }
            else if(cmd.contains("DeviceIntelligenBreaker"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toInt();
                disable    = query.value(10).toInt();
                parm[1]    = query.value(11).toString();
                parm[2]    = query.value(12).toString();
                parm[3]    = query.value(13).toString();
                parm[4]    = query.value(14).toString();
                parm[5]    = query.value(15).toString();
                parm[6]    = query.value(16).toString();
                describe   = "state#I,lineU#I,leakageI#I,lineP#I,modelT#I,lineI#I,electricityNum#I";
            }
            else if(cmd.contains("DeviceLight"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                disable    = query.value(12).toInt();
                parm[0]    = query.value(10).toString();
                parm[1]    = query.value(11).toString();
                describe   = "luminance#I,color#I";
            }
            else if(cmd.contains("DeviceLock"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status     = query.value(9).toInt();
                disable    = query.value(10).toInt();
            }
            else if(cmd.contains("DeviceMonitor"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                parm[2]    = query.value(11).toString();
                disable    = query.value(12).toInt();
                describe   = "cameraID#T,cameraNo#I,verifyCode#T";
            }
            else if(cmd.contains("DevicePowerSequencer"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "state#I,powerState#I";
            }
            else if(cmd.contains("DeviceProjector"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                parm[0]    = query.value(9).toString();
                parm[1]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "state#I,source#I";
            }
            else if(cmd.contains("DeviceRemoteControl"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(3).toString();
                deviceType = query.value(1).toInt();
                positionID = query.value(2).toString();
                manufacture= query.value(6).toString();
                moduleInfo = query.value(4).toString();
                unitType   = query.value(7).toString();
                ipAddress  = query.value(8).toString();
                secondType = query.value(5).toString();
                status     = query.value(9).toInt();
                disable    = query.value(10).toInt();
            }
            else if(cmd.contains("DeviceSingleSensor"))
            {
                deviceID   = query.value(0).toString();
                deviceType = query.value(1).toInt();
                positionID = query.value(2).toString();
                deviceName = query.value(3).toString();
                manufacture= query.value(4).toString();
                secondType = query.value(5).toString();
                unitType   = query.value(6).toString();
                ipAddress  = query.value(7).toString();
                moduleInfo = query.value(8).toString();
                status     = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                disable    = query.value(11).toInt();
                describe   = "value#I";
            }
            else if(cmd.contains("DeviceTrigger"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(3).toString();
                deviceType = query.value(1).toInt();
                positionID = query.value(2).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                parm[0]    = query.value(9).toString();
                disable    = query.value(10).toInt();
                describe   = "state#I";
            }
            else if(cmd.contains("DeviceTV"))
            {
                deviceID   = query.value(0).toString();
                deviceName = query.value(1).toString();
                deviceType = query.value(2).toInt();
                positionID = query.value(3).toString();
                manufacture= query.value(4).toString();
                unitType   = query.value(5).toString();
                ipAddress  = query.value(6).toString();
                moduleInfo = query.value(7).toString();
                secondType = query.value(8).toString();
                status    = query.value(9).toInt();
                parm[0]    = query.value(10).toString();
                parm[1]    = query.value(11).toString();
                disable    = query.value(12).toInt();
                describe   = "channel#I,volume#I";
            }
            QString result ;
            result=deviceID+" "+deviceName+" "+QString::number(deviceType)+" "+positionID
                    +" "+manufacture+" "+unitType+" "+ipAddress+" "+moduleInfo
                    +" "+secondType+" "+QString::number(status);
            qDebug()<<result;
            QSqlQuery query2;
            query2.prepare("INSERT INTO DeviceALL (deviceID,deviceName,deviceType,positionID,"
                           "manufacture,unitType,ipAddress,moduleInfo,secondType,status,disable,"
                           "parameter_1,parameter_2,parameter_3,parameter_4,parameter_5,parameter_6,"
                           "parameter_7,parameter_8,parameter_9,parameter_10,parameter_11,parameter_12,"
                           "describe) "
                           "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            query2.bindValue("deviceID", deviceID);
            query2.bindValue("deviceName", deviceName);
            query2.bindValue("deviceType", deviceType);
            query2.bindValue("positionID", positionID);

            query2.bindValue("manufacture", manufacture);
            query2.bindValue("unitType", unitType);
            query2.bindValue("ipAddress", ipAddress);
            query2.bindValue("moduleInfo", moduleInfo);

            query2.bindValue("secondType", secondType);
            query2.bindValue("status", status);
            query2.bindValue("disable", disable);
            query2.bindValue("parameter_1", parm[0]);

            query2.bindValue("parameter_2", parm[1]);
            query2.bindValue("parameter_3", parm[2]);
            query2.bindValue("parameter_4", parm[3]);

            query2.bindValue("parameter_5", parm[4]);
            query2.bindValue("parameter_6", parm[5]);
            query2.bindValue("parameter_7", parm[6]);
            query2.bindValue("parameter_8", parm[7]);
            query2.bindValue("parameter_9", parm[8]);
            query2.bindValue("parameter_10", parm[9]);
            query2.bindValue("parameter_11", parm[10]);
            query2.bindValue("parameter_12", parm[11]);
            query2.bindValue("describe", describe);

            qDebug()<<query2.executedQuery ();
            qDebug()<<query2.exec();
        }
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("sqlite3.sqlite");
    bool ok = db.open();
    if(ok)
    {
        if(db.tables().contains("DeviceALL"))
        {
            QSqlQuery queryDelTable;
            bool DropTabletableok= queryDelTable.exec("DROP TABLE DeviceALL");
            if(DropTabletableok==true)
            {
                qDebug()<<"DropTabletableok";
            }
        }
        if(!db.tables().contains("DeviceALL"))
        {
            QSqlQuery queryCreatTable;
            bool creattableok= queryCreatTable.exec("CREATE TABLE [DeviceALL](\
                                                    [deviceID] TEXT NOT NULL, \
                                                    [deviceName] TEXT,\
                                                    [deviceType] INTEGER, \
                                                    [positionID] TEXT, \
                                                    [manufacture] TEXT, \
                                                    [unitType] TEXT, \
                                                    [ipAddress] TEXT, \
                                                    [moduleInfo] TEXT, \
                                                    [secondType] INTEGER, \
                                                    [status] INTEGER, \
                                                    [disable] INTEGER DEFAULT (1), \
                                                    [describe] TEXT,\
                                                    [parameter_1] TEXT, \
                                                    [parameter_2] TEXT, \
                                                    [parameter_3] TEXT, \
                                                    [parameter_4] TEXT, \
                                                    [parameter_5] TEXT, \
                                                    [parameter_6] TEXT, \
                                                    [parameter_7] TEXT, \
                                                    [parameter_8] TEXT, \
                                                    [parameter_9] TEXT, \
                                                    [parameter_10] TEXT, \
                                                    [parameter_11] TEXT, \
                                                    [parameter_12] TEXT);");
            if(creattableok==true)
            {
                qDebug()<<"creattableok";
            }
        }
        QString cmd="SELECT * FROM DeviceAircond";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceAirQuality";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceAudio";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceButton";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceComplexSensor";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceCurtain";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceDecoder";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceDivAdjust";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceFreshAir";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceIntelligenBreaker";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceLight";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceLock";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceMonitor";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DevicePowerSequencer";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceProjector";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceRemoteControl";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceSingleSensor";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceTrigger";
        DealOLDTABLE(cmd);
        cmd="SELECT * FROM DeviceTV";
        DealOLDTABLE(cmd);
    }
    return a.exec();
}
